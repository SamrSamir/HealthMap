var app=angular.module("myApp",['chart.js']);

app.service('Map', function($q, $window) {



    this.init = function() {
        var options = {
            center: new google.maps.LatLng(23.7127837, 49.00594130000002),
            zoom: 4,
            disableDefaultUI: true
        }
        this.map = new google.maps.Map(
            document.getElementById("map"), options
        );
        this.places = new google.maps.places.PlacesService(this.map);
    }

    this.search = function(str) {
        var d = $q.defer();
        this.places.textSearch({query: str}, function(results, status) {
            if (status == 'OK') {
                d.resolve(results[0]);
            }
            else d.reject(status);
        });
        return d.promise;
    }

    this.setZoom=function(res)
    {
        this.map.setCenter(res.geometry.location);
        this.map.setZoom(7);
    }

    this.addMarker = function(res,index) {
       // if(this.marker) this.marker.setMap(null);


        this.marker = new google.maps.Marker({
            map: this.map,
            position: res,
            animation: google.maps.Animation.DROP

        });

        google.maps.event.addListener(this.marker, 'click', function() {
            localStorage.setItem("Index", index);


            $window.location.href = '../templates/report.html';
        });


        //this.map.setCenter(res);
    }

});

app.controller('MapController', function($scope, Map, $http) {

    $scope.place = {};

    $scope.search = function() {
        $scope.apiError = false;
        Map.search($scope.searchPlace)
            .then(
            function(res) { // success
                Map.setZoom(res);

                $scope.place.name = res.name;
                $scope.place.lat = res.geometry.location.lat();
                $scope.place.lng = res.geometry.location.lng();
            },
            function(status) { // error
                $scope.apiError = true;
                $scope.apiStatus = status;
            }
        );
    }

    $scope.send = function() {
        alert($scope.place.name + ' : ' + $scope.place.lat + ', ' + $scope.place.lng);
    }

    Map.init();


    var ref = new Firebase("https://healthxenvironment.firebaseio.com/reports");

    $scope.firebaseData=[];
    var counterMarker=0;
    var myLatLng = {};
    var locationArray=[];

    ref.on("child_added", function (snapshot){
        $scope.firebaseData.push(snapshot.val());

        console.log($scope.firebaseData[counterMarker].age);

        console.log($scope.firebaseData[counterMarker].currentLocation);

        if (!($scope.firebaseData[counterMarker].light==0 && $scope.firebaseData[counterMarker].medium==0 && $scope.firebaseData[counterMarker].intense==0))
        {
            if(!($scope.firebaseData[counterMarker].currentLocation==undefined)) {
                var latit = parseFloat($scope.firebaseData[counterMarker].currentLocation.split(',')[0]);
                var long = parseFloat($scope.firebaseData[counterMarker].currentLocation.split(',')[1]);
                myLatLng = {lat: latit, lng: long};
                //locationArray.push(myLatLng);

                Map.addMarker(myLatLng, counterMarker);

            }

        }

        counterMarker++;

    });

/*
    $http.get("../js/database.json")
        .success(
        function(data)
        {
            var jsonData=JSON.stringify(data);
            var js = JSON.parse(jsonData);

           // console.log(jsonData);

            var myLatLng = {};

            var locationArray=[];
            for(var i=0; i<js.length;i++)
            {
                var latit=parseFloat(js[i].location.location1.split(',')[0]);
                var long=parseFloat(js[i].location.location1.split(',')[1]);

                myLatLng = {lat: latit, lng: long};
                locationArray.push(myLatLng);
            }

        *//*    console.log(locationArray.length);
            console.log(locationArray[0].lat);

            console.log(locationArray[1].lat);*//*



            // var markerLocation=js.location.location1;
            for(var j=0; j<locationArray.length;j++) {
                Map.addMarker(locationArray[j], j, js);
            }
        }

    )
        .error();*/


}).controller('ReportController', function($scope, $http) {

    var index=localStorage.getItem("Index");
    var data=localStorage.getItem("Data");

    $scope.labels = ['Light', 'Medium', 'Intense'];




/*
$http.get("../js/database.json")
        .success(
        function(data)
        {
            var jsonData=JSON.stringify(data);
            var js = JSON.parse(jsonData);

           $scope.city=js[index].fromAPI2[0].name;
           $scope.country= js[index].fromAPI2[0].country.name;
           $scope.date=js[index].timeStamp;
            $scope.gender=js[index].gender;
            $scope.age=js[index].age;
            $scope.height=js[index].height;
            $scope.weight=js[index].weight;
            $scope.smoker=js[index].smoker;
            $scope.smokingFreq=js[index].smokingFreq;
            $scope.myColor=js[index].phlegm;
            $scope.coughType=js[index].coughType;
            var doctorVisit=js[index].doctor;
            if(doctorVisit==1)
            {
                $scope.doctor="Yes";
            }
            else
            {
                $scope.doctor="No";
            }

            $scope.symptoms=js[index].symptoms;
            $scope.allergies=js[index].allergies;
            $scope.diagnosis=js[index].initialDiagnosis;






        }).error();*/

    function convertKelvinToCelsius(kelvin) {
        if (kelvin < (0)) {
            return 'below absolute zero (0 K)';
        } else {
            return (kelvin-273.15);
        }
    }

    var ref = new Firebase("https://healthxenvironment.firebaseio.com/reports");

    $scope.firebaseData=[];
    var counter=0;
    ref.on("child_added", function (snapshot){
        $scope.firebaseData.push(snapshot.val());
        console.log(index);

        console.log($scope.firebaseData);

        if(counter==index) {
            $scope.age=$scope.firebaseData[index].age;
            $scope.gender=$scope.firebaseData[index].gender;
            $scope.height=$scope.firebaseData[index].height;
            $scope.weight=$scope.firebaseData[index].weight;
            $scope.smoker=$scope.firebaseData[index].smoker;
            $scope.smokingFreq=$scope.firebaseData[index].smokingFreq;
            $scope.myColor=$scope.firebaseData[index].phlegm;
            $scope.coughType=$scope.firebaseData[index].coughType;
            $scope.doctor=$scope.firebaseData[index].doctor;
            $scope.allergies=$scope.firebaseData[index].allergies;
            $scope.symptoms=$scope.firebaseData[index].symptoms;

            if($scope.firebaseData[index].doctor=="Yes") {
                $scope.diagnosis = $scope.firebaseData[index].initialDiagnosis;
            }
            else
            {
                $scope.diagnosis=["No Diagnosis"];
            }

            $scope.data = [
                [$scope.firebaseData[index].light,$scope.firebaseData[index].medium, $scope.firebaseData[index].intense]
            ];

            $scope.weather=$scope.firebaseData[index].fromAPI1.weather[0].main;
            $scope.weatherDescription=$scope.firebaseData[index].fromAPI1.weather[0].description;


            $scope.city=$scope.firebaseData[index].fromAPI1.name;
            $scope.country=$scope.firebaseData[index].fromAPI1.sys.country;
           // $scope.country=$scope.firebaseData[index].fromAPI1.sys.country;



            var temp=$scope.firebaseData[index].fromAPI1.main.temp;
            temp=parseFloat(temp);

            $scope.temperature=parseFloat(convertKelvinToCelsius(temp)).toFixed(2);
            $scope.date=$scope.firebaseData[index].timeStamp;

            $scope.pressure=$scope.firebaseData[index].fromAPI1.main.pressure;
            $scope.wid=$scope.firebaseData[index].fromAPI1.main.humidity + "%";
            $scope.seaLevel=$scope.firebaseData[index].fromAPI1.main.sea_level;
            $scope.groundLevel=$scope.firebaseData[index].fromAPI1.main.grnd_level;
            $scope.windSpeed=$scope.firebaseData[index].fromAPI1.wind.speed;
            $scope.windDirection=$scope.firebaseData[index].fromAPI1.wind.deg;

            $scope.plants=$scope.firebaseData[index].fromAPI2[0].plant_count;

            console.log($scope.firebaseData[index].fromAPI1.wind.deg);



            console.log($scope.firebaseData[index].age);
            console.log($scope.firebaseData[index].phlegm);


            $scope.labels2 = ['Past', 'Present', 'Future'];
            $scope.series2 = ['CO2 Emitted in Tons ', 'Consumed Energy in MWh'];

            //if(!(snapshot.child("Error:no matching locations").exists)) {

                $scope.data2 = [
                    [$scope.firebaseData[index].fromAPI2[0].carbon.past, $scope.firebaseData[index].fromAPI2[0].carbon.present, $scope.firebaseData[index].fromAPI2[0].carbon.future],
                    [$scope.firebaseData[index].fromAPI2[0].energy.past, $scope.firebaseData[index].fromAPI2[0].energy.present, $scope.firebaseData[index].fromAPI2[0].energy.future]
                ];


                $scope.labels3 = ["Past", "Present", "Future"];
                $scope.series3 = ['Carbon Intensity'];
                $scope.data3 = [
                    [$scope.firebaseData[index].fromAPI2[0].intensity.past, $scope.firebaseData[index].fromAPI2[0].intensity.present, $scope.firebaseData[index].fromAPI2[0].intensity.future]
                ];
                $scope.onClick = function (points, evt) {
                    console.log(points, evt);
                };

                $scope.elements = [{
                    "time": "Past",
                    "co2": $scope.firebaseData[index].fromAPI2[0].carbon.past,
                    "energy": $scope.firebaseData[index].fromAPI2[0].energy.past,
                    "intensity": $scope.firebaseData[index].fromAPI2[0].intensity.past,
                    "fossil": $scope.firebaseData[index].fromAPI2[0].fossil.past,
                    "hydro": $scope.firebaseData[index].fromAPI2[0].hydro.past,
                    "nuclear": $scope.firebaseData[index].fromAPI2[0].nuclear.past,
                    "other": $scope.firebaseData[index].fromAPI2[0].renewable.past
                },
                    {
                        "time": "Present",
                        "co2": $scope.firebaseData[index].fromAPI2[0].carbon.present,
                        "energy": $scope.firebaseData[index].fromAPI2[0].energy.present,
                        "intensity": $scope.firebaseData[index].fromAPI2[0].intensity.present,
                        "fossil": $scope.firebaseData[index].fromAPI2[0].fossil.present,
                        "hydro": $scope.firebaseData[index].fromAPI2[0].hydro.present,
                        "nuclear": $scope.firebaseData[index].fromAPI2[0].nuclear.present,
                        "other": $scope.firebaseData[index].fromAPI2[0].renewable.present
                    },
                    {
                        "time": "Future",
                        "co2": $scope.firebaseData[index].fromAPI2[0].carbon.future,
                        "energy": $scope.firebaseData[index].fromAPI2[0].energy.future,
                        "intensity": $scope.firebaseData[index].fromAPI2[0].intensity.future,
                        "fossil": $scope.firebaseData[index].fromAPI2[0].fossil.future,
                        "hydro": $scope.firebaseData[index].fromAPI2[0].hydro.future,
                        "nuclear": $scope.firebaseData[index].fromAPI2[0].nuclear.future,
                        "other": $scope.firebaseData[index].fromAPI2[0].renewable.future
                    }];

            }
          //  }

        counter++;

        $scope.$apply()
    });







});